G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.0*
G04 #@! TF.CreationDate,2025-06-14T13:15:45-05:00*
G04 #@! TF.ProjectId,BPS-CurrentScrutineeringPCB,4250532d-4375-4727-9265-6e7453637275,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.0) date 2025-06-14 13:15:45*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10R,1.700000X1.700000*%
%ADD11O,1.700000X1.700000*%
%ADD12C,3.000000*%
%ADD13RoundRect,0.250001X0.499999X0.759999X-0.499999X0.759999X-0.499999X-0.759999X0.499999X-0.759999X0*%
%ADD14O,1.500000X2.020000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J4*
X123025000Y-71420000D03*
D11*
X123025000Y-73960000D03*
X123025000Y-76500000D03*
X123025000Y-79040000D03*
X123025000Y-81580000D03*
G04 #@! TD*
D10*
G04 #@! TO.C,J3*
X158000000Y-71425000D03*
D11*
X158000000Y-73965000D03*
X158000000Y-76505000D03*
X158000000Y-79045000D03*
X158000000Y-81585000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,J1*
X146500000Y-65180000D03*
D13*
X148000000Y-69500000D03*
D14*
X145000000Y-69500000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,J2*
X135000000Y-65180000D03*
D13*
X136500000Y-69500000D03*
D14*
X133500000Y-69500000D03*
G04 #@! TD*
M02*
